# Things to fix

* markdown preview
* floatterm?
* debugger
* lualine tabline (normal mode tab cycling)
* cpp support for sourceswap, goto definition, search tags, etc
* neotest
